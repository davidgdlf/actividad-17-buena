class Alumno:#clase, entidad, modelo
    def __init__ (self, id , nombre,  email):#constructor
        self.id=id#almacenar en la instancia el parámetro
        self.nombre=nombre#string
        self.email=email#string
    def infoAlumno(self):#método de instancia
        print(f'Nombre: {self.nombre}, email: {self.email}')

alumno1=Alumno(1, 'mauro', 'maaruo@gmail.com')
alumno2=Alumno(2, 'ivan', 'ivan@gmail.com')
alumno1.infoAlumno()
alumno2.infoAlumno()

