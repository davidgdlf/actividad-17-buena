class Curso:#clase, entidad, modelo
    def __init__ (self, id , nombre,  creditos, añosdeestudio):
        self.id=id#almacenar en la instancia el parámetro
        self.nombre=nombre#string
        self.creditos=creditos
        self.añosdeestudio=añosdeestudio
    def info(self):#método de instancia
        print(f'Nombre: {self.nombre}, creditos obtenidos: {self.creditos} Años que lleva estudiando: {self.añosdeestudio}')

estudio1=Curso(1,'ingenieria',240,4)
estudio2=Curso(1,'matematicas',240,4)
estudio1.info()