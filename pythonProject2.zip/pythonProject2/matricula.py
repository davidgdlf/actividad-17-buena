from curso import Curso
from alumno import Alumno

class Matricula:#clase, entidad, modelo
    def __init__(self, idmatricula, fechamatricula, idalumno, idcurso):#constructor
        self.idmatricula=idmatricula
        self.fechamatricula=fechamatricula
        self.idalumno=idalumno
        self.idcurso=idcurso
    def infoMatricula(self):#método de instancia
        print(f'el alumno {self.idalumno}, en el curso {self.idcurso}  se matricula en {self.fechamatricula}')

alumno1=Alumno(1, 'mauro', 'maaruo@gmail.com')
estudio1=Curso(1,'ingenieria',240,4)
alumno2=Alumno(2, 'ivan', 'ivan@gmail.com')
estudio2=Curso(2,'matematicas',240,4)
alumno=Matricula(1, '12/12/2022', alumno1.nombre, estudio1.nombre )
alumno3=Matricula(2, '13/11/2022', alumno2.nombre, estudio1.nombre)
alumno4=Matricula(2, '13/11/2022', alumno2.nombre, estudio2.nombre)
alumno.infoMatricula()
alumno3.infoMatricula()
alumno4.infoMatricula()
